import React from "react";
import ntfLeft from "../images/ntfLeft.jpg";

const SideSection = () => {
  return (
    <div className="overflow-hidden col-start-1 col-end-8 relative">
      <img src={ntfLeft} alt="signUp logo" className="h-full w-full" />
    </div>
  );
};

export default SideSection;
