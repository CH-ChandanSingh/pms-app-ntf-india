import React from "react";

const ActualPriceGrid = ({ gridData }) => {
  return (
    <>
      {gridData.length > 0 && (
        <div className="col-span-full xl:col-span-12 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
          {/* Table */}
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              {/* Table header */}
              <thead className="text-xs font-semibold uppercase text-gray-600 dark:text-gray-500 bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50">
                <tr>
                  <th class="p-4 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Sr.
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Part No.
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      F. year
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PO Type
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Actual Price Q1
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Actual Price Q2
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Actual Price Q3
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Actual Price Q4
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                </tr>
              </thead>
              {/* Table body */}
              <tbody className="text-xs divide-y divide-gray-100 dark:divide-gray-700/60">
                {gridData.map((customer, index) => {
                  return (
                    <tr key={index}>
                      <td className="p-1 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="shrink-0 mr-2 sm:mr-3">
                            {index + 1}
                          </div>
                          <div className="font-medium text-gray-800 dark:text-gray-100"></div>
                        </div>
                      </td>
                      <td className="p-1 whitespace-nowrap font-medium text-green-500">
                        <div className="text-left">{customer.part_number}</div>
                      </td>
                      <td className="p-1 whitespace-nowrap">
                        <div className="text-left ">{customer.f_year}</div>
                      </td>
                      <td className="p-1 whitespace-nowrap">
                        <div className="text-left">{customer.po_type}</div>
                      </td>
                      <td className="p-1 whitespace-nowrap">
                        <div className="text-left">
                          {customer.actual_price_q1}
                        </div>
                      </td>
                      <td className="p-1 whitespace-nowrap">
                        <div className="text-left">
                          {customer.actual_price_q2}
                        </div>
                      </td>
                      <td className="p-1 whitespace-nowrap">
                        <div className="text-left">
                          {customer.actual_price_q3}
                        </div>
                      </td>
                      <td className="p-1 whitespace-nowrap">
                        <div className="text-left">
                          {customer.actual_price_q4}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
};

export default ActualPriceGrid;
