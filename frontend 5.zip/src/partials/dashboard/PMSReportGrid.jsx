import React, { useEffect, useState } from "react";
import axios from "axios";
import download from "../../images/download.png";

function PMSReportGrid({ setCsvData, isLoading }) {
  const [gridData, setGridData] = React.useState([]);

  const fetchData = async () => {
    try {
      await axios
        .get("http://localhost:5000/pms")
        .then((response) => {
          let dataSet = [];
          setGridData(response.data.data);
          response.data.data.map((row, index) => {
            let q2_ntf_actual_po_price = 0;
            let q3_ntf_actual_po_price = 0;
            let q4_ntf_actual_po_price = 0;
            let q1_ntf_actual_po_price = 0;

            let q2_ntf_to_be_po_price = 0;
            let q3_ntf_to_be_po_price = 0;
            let q4_ntf_to_be_po_price = 0;
            let q1_ntf_to_be_po_price = 0;

            let pcd_1 = 0;
            let pcd_2 = 0;
            let pcd_3 = 0;
            let pcd_4 = 0;

            // calculation of SOP Actualization
            let sop_actualization = 0;
            row?.cost_details.forEach((funds) => {
              sop_actualization += parseFloat(funds.rm_rate_rs_pc);
            });

            // PCD calculation

            if (row.pcd_1[row.pcd_1.length - 1] === "%") {
              pcd_1 = -(sop_actualization * parseFloat(row.pcd_1)) / 100;
            } else {
              pcd_1 = parseFloat(-row.pcd_1);
            }

            if (row.pcd_2[row.pcd_2.length - 1] === "%") {
              pcd_2 = -(sop_actualization * parseFloat(row.pcd_2)) / 100;
            } else {
              pcd_2 = parseFloat(-row.pcd_2);
            }

            if (row.pcd_3[row.pcd_3.length - 1] === "%") {
              pcd_3 = -(sop_actualization * parseFloat(row.pcd_3)) / 100;
            } else {
              pcd_3 = parseFloat(-row.pcd_3);
            }

            if (row.pcd_4[row.pcd_4.length - 1] === "%") {
              pcd_4 = -(sop_actualization * parseFloat(row.pcd_4)) / 100;
            } else {
              pcd_4 = parseFloat(-row.pcd_4);
            }

            // Calculation RM Movement
            let q2_rmMovement = 0;
            let q3_rmMovement = 0;
            let q4_rmMovement = 0;
            let q1_rmMovement = 0;

            q2_ntf_actual_po_price = row?.actual_price[0]?.actual_price_q2;
            q3_ntf_actual_po_price = row?.actual_price[0]?.actual_price_q3;
            q4_ntf_actual_po_price = row?.actual_price[0]?.actual_price_q4;
            q1_ntf_actual_po_price = row?.actual_price[0]?.actual_price_q4;

            row?.cost_details?.forEach((rm) => {
              q2_rmMovement += rm?.rm_movement[0]?.q2_rate_movement
                ? parseFloat(rm?.rm_movement[0]?.q2_rate_movement)
                : 0;
              q3_rmMovement += rm?.rm_movement[0]?.q3_rate_movement
                ? parseFloat(rm?.rm_movement[0]?.q3_rate_movement)
                : 0;
              q4_rmMovement += rm?.rm_movement[0]?.q4_rate_movement
                ? parseFloat(rm?.rm_movement[0]?.q4_rate_movement)
                : 0;
              q1_rmMovement += parseFloat(
                rm?.rm_movement[0]?.q1_rate_movement !== undefined
                  ? rm?.rm_movement[0]?.q1_rate_movement
                  : 0
              );
            });

            // NTF to be PO Price
            q2_ntf_to_be_po_price =
              parseFloat(sop_actualization) + parseFloat(q2_rmMovement);
            q3_ntf_to_be_po_price = (
              parseFloat(q2_ntf_to_be_po_price) + parseFloat(q3_rmMovement)
            ).toFixed(2);
            q4_ntf_to_be_po_price = (
              parseFloat(q3_ntf_to_be_po_price) +
              parseFloat(q4_rmMovement) +
              parseFloat(pcd_1)
            ).toFixed(2);
            q1_ntf_to_be_po_price = (
              parseFloat(q4_ntf_to_be_po_price) +
              parseFloat(q1_rmMovement) +
              parseFloat(pcd_2)
            ).toFixed(2);

            // Impact
            let q2_impact =
              parseFloat(q2_ntf_actual_po_price) -
              parseFloat(q2_ntf_to_be_po_price);
            let q3_impact =
              parseFloat(q3_ntf_actual_po_price) -
              parseFloat(q3_ntf_to_be_po_price);
            let q4_impact =
              parseFloat(q4_ntf_actual_po_price) -
              parseFloat(q4_ntf_to_be_po_price);
            let q1_impact =
              parseFloat(q1_ntf_actual_po_price) -
              parseFloat(q1_ntf_to_be_po_price);

            dataSet.push({
              "Sr.": String(index + 1),
              "Part No.": row?.part_number,
              "Part Name": row?.part_name,
              "Model Name": row?.model,
              "vendor code": row?.vendor_code,
              "SOP Actualization Q2": String(sop_actualization),
              "RM Movement Q2": q2_rmMovement.toFixed(2),
              "NTF To Be PO Price Q2": String(q2_ntf_to_be_po_price),
              "NTF Actual PO Price Q2": String(q2_ntf_actual_po_price),
              "Impact Q2": q2_impact,
              "RM Movement Q3": q3_rmMovement.toFixed(2),
              "NTF To Be PO Price Q3": String(q3_ntf_to_be_po_price),
              "NTF Actual PO Price Q3": String(q3_ntf_actual_po_price),
              "Impact Q3": q3_impact,
              "RM Movement Q4": q4_rmMovement.toFixed(2),
              "PCD1 Q4": pcd_1.toFixed(2),
              "To Be PO Price Q4": String(q4_ntf_to_be_po_price),
              "NTF Actual PO Price Q4": String(q4_ntf_actual_po_price),
              "Impact Q4": q4_impact,
              "PCD2  Q1": pcd_2.toFixed(2),
              "To Be PO Price Q1": String(q1_ntf_to_be_po_price),
              "NTF Actual PO Price Q1": String(q1_ntf_actual_po_price),
              "Impact Q1": q1_impact,

              // "PCD3 ": pcd_3,
              // "To Be PO Price Q1": "",
              // "NTF Actual PO Price Q1": "",
              // "Impact Q1": "",
              // "PCD4 ": pcd_4,
              // "To Be PO Price ": "",
              // "NTF Actual PO Price": "",
              // "Impact ": "",
            });
          });

          setCsvData(dataSet);
          isLoading(true);
        })
        .catch((err) => {
          console.log("Failed: " + err);
        });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // Call fetchData on component mount
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="col-span-full xl:col-span-12 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
      {/* Table */}
      <div className="overflow-x-auto">
        <table className="table-auto w-full">
          {/* Table header */}
          <thead className="text-xs font-semibold uppercase text-gray-600 dark:text-gray-500 bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50">
            <tr>
              <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                  Sr.
                </p>
              </th>
              <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50 text-left">
                <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                  Part No.
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="2"
                    stroke="currentColor"
                    aria-hidden="true"
                    className="w-5 h-5"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                    ></path>
                  </svg>
                </p>
              </th>
              <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                  Part Name
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="2"
                    stroke="currentColor"
                    aria-hidden="true"
                    className="w-5 h-5"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                    ></path>
                  </svg>
                </p>
              </th>
              <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                  Model
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="2"
                    stroke="currentColor"
                    aria-hidden="true"
                    className="w-5 h-5"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                    ></path>
                  </svg>
                </p>
              </th>
              <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                  Vendor Code
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="2"
                    stroke="currentColor"
                    aria-hidden="true"
                    className="w-5 h-5"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                    ></path>
                  </svg>
                </p>
              </th>
            </tr>
          </thead>
          {/* Table body */}
          <tbody className="text-xs divide-y divide-gray-100 dark:divide-gray-700/60">
            {gridData.map((customer, index) => {
              return (
                <tr key={index}>
                  <td className="px-1 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className=" shrink-0 mr-2 sm:mr-3">{index + 1}</div>
                      <div className="font-medium text-gray-800 dark:text-gray-100"></div>
                    </div>
                  </td>
                  <td className="px-1 whitespace-nowrap font-medium text-green-500">
                    <div className="text-left">{customer.part_number}</div>
                  </td>
                  <td className="px-1 whitespace-nowrap">
                    <div className="text-left ">{customer.part_name}</div>
                  </td>
                  <td className="px-1 whitespace-nowrap">
                    <div className="text-left">{customer.model}</div>
                  </td>
                  <td className="px-1 whitespace-nowrap">
                    <div className="text-left">{customer.vendor_code}</div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default PMSReportGrid;
