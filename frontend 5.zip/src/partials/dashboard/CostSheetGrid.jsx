import React from "react";

const CostSheetGrid = ({ gridData }) => {
  return (
    <>
      {gridData.length > 0 && (
        <div className="col-span-full xl:col-span-12 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
          {/* Table */}
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              {/* Table header */}
              <thead className="text-xs font-semibold uppercase text-gray-600 dark:text-gray-500 bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50">
                <tr>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Sr.
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Part No.
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  {/* <th className="whitespace-nowrap">
                  <div className="font-semibold text-left">Part Name</div>
                </th>
                <th className="whitespace-nowrap">
                  <div className="font-semibold text-left">PO Type</div>
                </th>
                <th className="whitespace-nowrap">
                  <div className="font-semibold text-center">Model</div>
                </th>
                <th className="whitespace-nowrap">
                  <div className="font-semibold text-center">RM Base</div>
                </th>
                <th className="whitespace-nowrap">
                  <div className="font-semibold text-center">SOP</div>
                </th>
                <th className="whitespace-nowrap">
                  <div className="font-semibold text-center">VCode</div>
                </th> 
                <th className="whitespace-nowrap">
                  <div className="font-semibold text-center">
                    Cost
                    <br /> Type
                  </div>
                </th>*/}
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70 ">
                      RM Name
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Supplier
                      <br /> Name
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="2"
                        stroke="currentColor"
                        aria-hidden="true"
                        className="w-5 h-5"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
                        ></path>
                      </svg>
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Weight
                      <br /> Kg/Pc
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Rate
                      <br /> R/Kg
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Rate
                      <br /> Rs/Pc
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      Indexing
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 1
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 1<br /> Date
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 2
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 2<br /> Date
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 3
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 3<br /> Date
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 4
                    </p>
                  </th>
                  <th class="p-1 transition-colors cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 hover:bg-blue-gray-50">
                    <p class="flex items-center justify-between gap-2 font-sans text-xs antialiased font-semibold leading-none text-blue-gray-900 opacity-70">
                      PCD 4<br /> Date
                    </p>
                  </th>
                </tr>
              </thead>
              {/* Table body */}
              <tbody className="text-xs divide-y divide-gray-100 dark:divide-gray-700/60">
                {gridData.map((customer, index) => {
                  return (
                    <tr key={index}>
                      <td className="whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="shrink-0 mr-2 sm:mr-3">
                            {index + 1}
                          </div>
                          <div className="font-medium text-gray-800 dark:text-gray-100"></div>
                        </div>
                      </td>
                      <td className="whitespace-nowrap font-medium text-green-500">
                        <div className="text-left">
                          {customer.part_details.part_number}
                        </div>
                      </td>
                      {/* <td className="whitespace-nowrap">
                      <div className="text-left ">
                        {customer.part_details.part_name}
                      </div>
                    </td>
                    <td className="whitespace-nowrap">
                      <div className="text-center">
                        {customer.part_details.po_type}
                      </div>
                    </td>
                    <td className="whitespace-nowrap">
                      <div className="text-center">
                        {customer.part_details.model}
                      </div>
                    </td>
                    <td className="whitespace-nowrap font-medium text-green-500">
                      <div className="text-left">
                        {customer.part_details.rm_base}
                      </div>
                    </td>
                    <td className="whitespace-nowrap">
                      <div className="text-left ">
                        {customer.part_details.sop}
                      </div>
                    </td>
                    <td className="whitespace-nowrap">
                      <div className="text-center">
                        {customer.part_details.vendor_code}
                      </div>
                    </td> 
                    <td className="whitespace-nowrap">
                      <div className="text-center">{customer.cost_type}</div>
                    </td>*/}
                      <td className="whitespace-nowrap">
                        <div className="text-left">{customer.rm_name}</div>
                      </td>
                      <td className="whitespace-nowrap">
                        <div className="text-left">
                          {customer.supplier_name}
                        </div>
                      </td>
                      <td className="whitespace-nowrap">
                        <div className="text-left">
                          {customer.rm_weight_kg_pc}
                        </div>
                      </td>
                      <td className="whitespace-nowrap">
                        <div className="text-left">
                          {customer.rm_rate_rs_kg}
                        </div>
                      </td>
                      <td className="whitespace-nowrap">
                        <div className="text-left">
                          {customer.rm_rate_rs_pc}
                        </div>
                      </td>
                      <td className="whitespace-nowrap">
                        <div className="text-left">
                          {customer.indexing_msil_directed}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_1}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_1_date}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_2}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_2_date}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_3}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_3_date}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_4}
                        </div>
                      </td>
                      <td className="whitespace-nowrap ">
                        <div className="text-left">
                          {customer.part_details.pcd_4_date}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
};

export default CostSheetGrid;
