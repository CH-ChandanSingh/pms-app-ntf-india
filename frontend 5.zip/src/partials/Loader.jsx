import React from "react";
import ReactLoading from "react-loading";

const Loader = () => {
  return (
    <div className="search-loader">
      <ReactLoading color="#22d3ee" />
    </div>
  );
};

export default Loader;
