import React, { useEffect, useState } from "react";
import * as XLSX from "xlsx";
import Sidebar from "../partials/Sidebar";
import Header from "../partials/Header";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import RMMovementGrid from "../partials/dashboard/RMMovementGrid";
import download from "../images/download.png";
import Loader from "../partials/Loader";
import { exportRmMovementToCSV } from "../utils/Utils";

function RmMovement() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, isLoading] = useState(false);
  const [gridData, setGridData] = React.useState([]);
  const [fileName, setFileName] = React.useState("RmMovement");
  const [csvData, setCsvData] = React.useState([]);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = async (event) => {
      const workbook = XLSX.read(event.target.result, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const sheetData = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        blankrows: false,
      });

      let dataArraySet = [];
      sheetData.slice(2, sheetData.length).forEach((row) => {
        dataArraySet.push({
          rm_name: row[0],
          supplier_name: row[1],
          f_year: sheetData[1][3].split(" ")[2],
          q1: row[2],
          q2: row[3],
          q3: row[4],
          q4: row[5],
        });
      });

      try {
        const response = await axios.post(
          "http://localhost:5000/rmMovement",
          dataArraySet
        );
        fetchData();
        toast(response.data.message);
      } catch (error) {
        console.error("Error creating post:", error);
      }
    };

    reader.readAsBinaryString(file);
  };

  const fetchData = async () => {
    try {
      await axios
        .get("http://localhost:5000/rmMovementList")
        .then((response) => {
          isLoading(true);
          setGridData(response.data.data);

          let dataCSVSet = [];
          response.data.data
            .slice(1, response.data.data.length)
            .forEach((row) => {
              dataCSVSet.push({
                rm_name: row["rm_name"],
                supplier_name: row["supplier_name"],
                q1: row["q1"],
                q2: row["q2"],
                q3: row["q3"],
                q4: row["q4"],
              });
            });

          setCsvData(dataCSVSet);
        })
        .catch((err) => {
          console.log("Failed: " + err);
        });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // Call fetchData on component mount
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      <div className="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
        <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

        <main className="grow">
          <header className="px-5 pt-4 border-b border-gray-100 dark:border-gray-700/60">
            <div className="grid grid-cols-12 gap-6">
              <div className="col-span-3">
                <h1 className="text-2xl md:text-3xl text-gray-800 dark:text-gray-100 font-bold">
                  Rm Movement
                </h1>
              </div>
              <div className="col-span-2"></div>
              <div className="col-span-3">
                <div className="flex items-left justify-left">
                  <label
                    for="dropzone-file"
                    className="flex flex-col items-center justify-center w-[100%] h-34 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-gray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500"
                  >
                    <div className="flex flex-col items-center justify-center">
                      <svg
                        className="w-8 h-8 text-gray-500 dark:text-gray-400"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 20 16"
                      >
                        <path
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                        />
                      </svg>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        <span className="font-semibold">Click to upload </span>
                        or drag and drop
                      </span>
                    </div>
                    <input
                      id="dropzone-file"
                      type="file"
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                  </label>
                </div>
              </div>
              <div className="col-span-2"></div>
              <div className="col-span-2">
                <button>
                  <img
                    src={download}
                    alt="Download"
                    title="Download Rm Movement"
                    onClick={(e) => exportRmMovementToCSV(csvData, fileName)}
                  />
                </button>
              </div>
            </div>
          </header>
          <div className="px-4 sm:px-6 lg:px-4 w-full max-w-9xl mx-auto">
            <div className="items-center justify-center mt-2 w-full">
              {!loading && <Loader />}
              {gridData && (
                <RMMovementGrid className="margin 0 auto" gridData={gridData} />
              )}
            </div>
          </div>
        </main>
      </div>
      <ToastContainer />
    </div>
  );
}

export default RmMovement;
