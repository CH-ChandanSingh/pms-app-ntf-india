import React from "react";
import SideSection from "../components/SideSection";
import { Link } from "react-router-dom";

const ForgotPassword = () => {
  return (
    <>
      <div className="w-full h-screen grid grid-cols-12">
        <SideSection />
        <div className="bg-[#F8FAFC] h-full px-20 grid grid-cols-1 gap-3 col-start-8 col-end-13">
          <div>
            <div className="flex justify-center items-center py-10">
              <h1 className="font-bold text-2xl text-[#0F172A]">
                Forgot Password
              </h1>
            </div>
            <form>
              <div className="grid grid-cols-1 gap-10">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-[#334155]">
                    Enter email to receive reset link
                  </label>
                  <input
                    className="shadow-sm appearance-none border rounded-xl w-full py-3 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    type="email"
                    required
                  />
                </div>
                <div>
                  <button
                    className="bg-[#2e6fdc]  text-base text-white font-bold rounded-lg w-full h-12"
                    type="submit"
                  >
                    Send link
                  </button>
                  <div className="flex justify-center items-center mt-1">
                    <Link to="/login" className="text-[#475569] underline">
                      Log in
                    </Link>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;
