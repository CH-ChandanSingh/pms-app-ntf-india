import React from "react";
import { Link } from "react-router-dom";
import ntfLeft from "../images/ntfLeft.jpg";
import SideSection from "../components/SideSection";

const SignUp = () => {
  return (
    <>
      <div className="w-full h-screen grid grid-cols-12">
        <SideSection />
        <div className="bg-[#F8FAFC] h-full px-20 grid grid-cols-1 gap-3 col-start-8 col-end-13">
          <div>
            <div className="flex justify-center items-center py-8 2xl:py-12 relative">
              <h1 className="font-bold text-2xl 2xl:3xl text-[#0F172A]">
                Sign Up
              </h1>
            </div>
            <form>
              <div className="grid grid-cols-1 gap-5">
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Full name
                  </label>
                  <input
                    className="shadow-sm appearance-none border rounded-xl w-full py-3 px-3 text-gray-700 focus:outline-none focus:shadow-outline"
                    type="text"
                    placeholder="What is your name?"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Email
                  </label>
                  <input
                    className="shadow-sm appearance-none border rounded-xl w-full py-3 px-3 text-gray-700 focus:outline-none focus:shadow-outline"
                    type="email"
                    placeholder="Tell us your Email ID"
                    required
                  />
                </div>
                <div></div>

                <div className="grid grid-cols-2 gap-5">
                  <div className="">
                    <label className="block text-sm font-semibold mb-2">
                      Password
                    </label>
                    <input
                      className="shadow-sm appearance-none border rounded-xl w-full py-3 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      type="password"
                      placeholder="Create a password"
                      required
                    />
                  </div>
                  <div className="">
                    <label className="block text-sm font-semibold mb-2">
                      Mobile number
                    </label>
                    <div className="relative">
                      <input
                        className="shadow-sm appearance-none border rounded-xl w-full py-3 pl-10 pr-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        type="number"
                        placeholder="Mobile Number"
                        required
                      />
                      <span className="absolute top-3 left-1">+91</span>
                    </div>
                  </div>
                </div>
                <div>
                  <button
                    className="bg-[#2e6fdc] text-white font-bold rounded-lg w-full h-12"
                    type="submit"
                  >
                    Register now
                  </button>
                  <div className="flex justify-center font-semibold items-center text-sm mt-2">
                    <span className=" text-[#94A3B8] mr-1">
                      Already have an account?
                    </span>
                    <Link to="/login" className=" underline">
                      {" "}
                      Login
                    </Link>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignUp;
