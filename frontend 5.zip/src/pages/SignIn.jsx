import React from "react";
import { Link } from "react-router-dom";
import SideSection from "../components/SideSection";

const SignIn = () => {
  return (
    <>
      <div className="w-full h-screen grid grid-cols-12">
        <SideSection />
        <div className="bg-[#F8FAFC] h-full px-20 grid grid-cols-1 gap-3 col-start-8 col-end-13">
          <div>
            <div className="flex justify-center items-center py-8 2xl:py-12">
              <h1 className="font-bold text-2xl 2xl:text-3xl text-[#0F172A]">
                Log In
              </h1>
            </div>
            <div className="grid grid-cols-1 mt-4 gap-5">
              <div className="text-sm font-semibold flex flex-col gap-2 justify-center">
                <div className=" grid grid-cols-1 gap-5">
                  <div>
                    <form>
                      <div className="grid grid-cols-1 gap-5 2xl:gap-6">
                        <div>
                          <label className="block text-sm 2xl:text-base font-semibold mb-2">
                            Email
                          </label>
                          <input
                            className="shadow-sm appearance-none border rounded-xl w-full py-3 2xl:text-base px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            type="email"
                            placeholder="Tell us your Email ID"
                            required
                          />
                        </div>
                        <div className="">
                          <label className="block text-sm 2xl:text-base font-semibold mb-2">
                            Password
                          </label>
                          <input
                            className="shadow-sm appearance-none border rounded-xl w-full py-3 px-3 2xl:text-base  text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            type="password"
                            placeholder="Put password for your account"
                            required
                          />
                          <div className="flex justify-between items-center">
                            <Link
                              to="/forgotPassword"
                              className="font-normal text-xs 2xl:text-sm text-blue-500 cursor-pointer"
                            >
                              Forgot Password?
                            </Link>
                          </div>
                        </div>
                        <div>
                          <button
                            className="bg-[#2e6fdc] text-base 2xl:text-lg text-white font-bold rounded-lg w-full h-12 2xl:h-14"
                            type="submit"
                          >
                            Log In
                          </button>
                        </div>
                      </div>
                    </form>
                    <div className="flex justify-center items-center text-sm 2xl:text-base mt-2">
                      <span className=" text-[#94A3B8] mr-1">
                        Don't have an account?
                      </span>
                      <Link to="/registration" className="underline">
                        {" "}
                        Sign Up
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignIn;
