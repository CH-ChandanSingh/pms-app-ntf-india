import React, { useEffect, useState } from "react";
import * as XLSX from "xlsx";
import Sidebar from "../partials/Sidebar";
import Header from "../partials/Header";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import CostSheetGrid from "../partials/dashboard/CostSheetGrid";
import download from "../images/download.png";
import Loader from "../partials/Loader";
import { exportTCostSheetToCSV } from "../utils/Utils";

function CostSheet() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [data, setData] = React.useState(null);
  const [loading, isLoading] = useState(false);
  const [dataUpload, setDataUpload] = React.useState(false);
  const [gridData, setGridData] = React.useState([]);
  const [fileName, setFileName] = React.useState("CostPrice");
  const [csvData, setCsvData] = React.useState([]);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = async (event) => {
      const workbook = XLSX.read(event.target.result, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const sheetData = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        blankrows: false,
      });

      let dataArraySet = [];
      let partCostMap = new Map();
      sheetData.slice(2, sheetData.length).forEach((row) => {
        const partNumber = row[0];
        const costEntry = {
          cost_type: row[7],
          rm_name: row[8],
          supplier_name: row[9],
          rm_weight_kg_pc: row[10] ? row[10] : 0,
          rm_rate_rs_kg: row[11] ? row[11] : 0,
          rm_rate_rs_pc: row[12] ? row[12] : 0,
          indexing_msil_directed: row[13],
        };

        if (!partCostMap.has(partNumber)) {
          partCostMap.set(partNumber, {
            part_number: partNumber,
            part_name: row[1],
            po_type_id: row[2],
            model_id: row[3],
            rm_base: row[4],
            sop: row[5],
            vendor_code: row[6],
            pcd_1: row[14],
            pcd_1_date: row[15],
            pcd_2: row[16],
            pcd_2_date: row[17],
            pcd_3: row[18],
            pcd_3_date: row[19],
            pcd_4: row[20],
            pcd_4_date: row[21],
            cost: [costEntry],
          });
        } else {
          partCostMap.get(partNumber).cost.push(costEntry);
        }
      });

      dataArraySet = Array.from(partCostMap.values());
      try {
        const response = await axios.post(
          "http://localhost:5000/costSheet",
          dataArraySet
        );
        setDataUpload(true);
        toast(response.data.message);
      } catch (error) {
        toast.error("Error creating post");
        console.error("Error creating post:", error);
      }
    };

    reader.readAsBinaryString(file);
  };

  const fetchData = async () => {
    try {
      await axios
        .get("http://localhost:5000/costSheetList")
        .then((response) => {
          setGridData(response.data.data);
          isLoading(true);

          let dataCSVSet = [];
          response.data.data
            .slice(1, response.data.data.length)
            .forEach((row) => {
              dataCSVSet.push({
                part_number: row.part_details.part_number,
                part_name: row.part_details.part_name,
                po_type: row.part_details.po_type,
                model: row.part_details.model,
                rm_base: row.part_details.rm_base,
                sop: row.part_details.sop,
                vendor_code: row.part_details.vendor_code,
                cost_type: row.cost_type,
                rm_name: row.rm_name,
                supplier_name: row.supplier_name,
                rm_weight_kg_pc: row.rm_weight_kg_pc ? row.rm_weight_kg_pc : 0,
                rm_rate_rs_kg: row.rm_rate_rs_kg ? row.rm_rate_rs_kg : 0,
                rm_rate_rs_pc: row.rm_rate_rs_pc ? row.rm_rate_rs_pc : 0,
                indexing_msil_directed: row.indexing_msil_directed,
                pcd_1: row.part_details.pcd_1,
                pcd_1_date: row.part_details.pcd_1_date,
                pcd_2: row.part_details.pcd_2,
                pcd_2_date: row.part_details.pcd_2_date,
                pcd_3: row.part_details.pcd_3,
                pcd_3_date: row.part_details.pcd_3_date,
                pcd_4: row.part_details.pcd_4,
                pcd_4_date: row.part_details.pcd_4_date,
              });
            });

          setCsvData(dataCSVSet);
        })
        .catch((err) => {
          console.log("Failed: " + err);
        });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // Call fetchData on component mount
  useEffect(() => {
    fetchData();
  }, [dataUpload]);
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      <div className="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
        <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        <main className="grow">
          <header className="px-5 pt-4 border-b border-gray-100 dark:border-gray-700/60">
            <div className="grid grid-cols-12 gap-6">
              <div className="col-span-2">
                <h1 className="text-2xl md:text-3xl text-gray-800 dark:text-gray-100 font-bold">
                  Cost Sheet
                </h1>
              </div>
              <div className="col-span-2"></div>
              <div className="col-span-4">
                <div className="flex items-left justify-left">
                  <label
                    for="dropzone-file"
                    className="flex flex-col items-center justify-center w-[100%] h-34 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-gray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500"
                  >
                    <div className="flex flex-col items-center justify-center">
                      <svg
                        className="w-8 h-8 text-gray-500 dark:text-gray-400"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 20 16"
                      >
                        <path
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                        />
                      </svg>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        <span className="font-semibold">Click to upload </span>
                        or drag and drop
                      </span>
                    </div>
                    <input
                      id="dropzone-file"
                      type="file"
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                  </label>
                </div>
              </div>
              <div className="col-span-2"></div>
              <div className="col-span-2">
                <button>
                  <img
                    src={download}
                    alt="Download"
                    title="Download PMS report"
                    onClick={(e) => exportTCostSheetToCSV(csvData, fileName)}
                  />
                </button>
              </div>
            </div>
          </header>
          <div className="px-4 sm:px-6 lg:px-4 w-full max-w-9xl mx-auto">
            <div className="items-center justify-center mt-2 w-full">
              {!loading && <Loader />}
              {gridData && <CostSheetGrid gridData={gridData} />}
            </div>
          </div>
        </main>
      </div>
      <ToastContainer />
    </div>
  );
}

export default CostSheet;
