import React, { useEffect, useState } from "react";
import * as XLSX from "xlsx";
import Sidebar from "../partials/Sidebar";
import Header from "../partials/Header";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ActualPriceGrid from "../partials/dashboard/ActualPriceGrid";
import download from "../images/download.png";
import Loader from "../partials/Loader";
import { exportActualPriceToCSV } from "../utils/Utils";
function ActualPrice() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, isLoading] = useState(false);
  const [fileName, setFileName] = React.useState("ActualPrice");
  const [csvData, setCsvData] = React.useState([]);
  const [gridData, setGridData] = React.useState([]);

  const fetchData = async () => {
    try {
      await axios
        .get("http://localhost:5000/actualPriceList")
        .then((response) => {
          setGridData(response.data.data);
          let dataCSVSet = [];
          response.data.data
            .slice(1, response.data.data.length)
            .forEach((row) => {
              dataCSVSet.push({
                part_name: row["part_number"],
                po_type: row["po_type"],
                actual_price_q1: row["actual_price_q1"],
                actual_price_q2: row["actual_price_q2"],
                actual_price_q3: row["actual_price_q3"],
                actual_price_q4: row["actual_price_q4"],
              });
            });

          setCsvData(dataCSVSet);
          isLoading(true);
        })
        .catch((err) => {
          console.log("Failed: " + err);
        });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = async (event) => {
      const workbook = XLSX.read(event.target.result, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const sheetData = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        blankrows: false,
      });

      let dataArraySet = [];
      sheetData.slice(1, sheetData.length).forEach((row) => {
        dataArraySet.push({
          part_name: row[0],
          f_year: sheetData[0][3].split(" ")[7],
          po_type: row[1],
          actual_price_q1: row[2],
          actual_price_q2: row[3],
          actual_price_q3: row[4],
          actual_price_q4: row[5],
        });
      });

      try {
        const response = await axios.post(
          "http://localhost:5000/actualPrice",
          dataArraySet
        );
        fetchData();
        toast(response.data.message);
      } catch (error) {
        toast.error("Error creating post");
        console.error("Error creating post:", error);
      }
    };

    reader.readAsBinaryString(file);
  };

  // Call fetchData on component mount
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      <div className="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
        <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

        <main className="grow">
          <header className="px-5 pt-4 border-b border-gray-100 dark:border-gray-700/60">
            <div className="grid grid-cols-12 gap-6">
              <div className="col-span-2">
                <h1 className="text-2xl md:text-3xl text-gray-800 dark:text-gray-100 font-bold">
                  Actual Price
                </h1>
              </div>
              <div className="col-span-2"></div>
              <div className="col-span-4">
                <div className="flex items-left justify-left">
                  <label
                    for="dropzone-file"
                    className="flex flex-col items-center justify-center w-[100%] h-34 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-gray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500"
                  >
                    <div className="flex flex-col items-center justify-center">
                      <svg
                        className="w-8 h-8 text-gray-500 dark:text-gray-400"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 20 16"
                      >
                        <path
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                        />
                      </svg>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        <span className="font-semibold">Click to upload </span>
                        or drag and drop
                      </span>
                    </div>
                    <input
                      id="dropzone-file"
                      type="file"
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                  </label>
                </div>
              </div>
              <div className="col-span-2"></div>
              <div className="col-span-2">
                <button>
                  <img
                    src={download}
                    alt="Download"
                    title="Download PMS report"
                    onClick={(e) => exportActualPriceToCSV(csvData, fileName)}
                  />
                </button>
              </div>
            </div>
          </header>

          <div className="px-4 sm:px-6 lg:px-4 w-full max-w-9xl mx-auto">
            <div className="items-center justify-center mt-2 w-full">
              {!loading && <Loader />}
              {gridData && <ActualPriceGrid gridData={gridData} />}
            </div>
          </div>
        </main>
      </div>
      <ToastContainer />
    </div>
  );
}

export default ActualPrice;
