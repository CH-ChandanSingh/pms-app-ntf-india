import React, { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";

import "./css/style.css";

import "./charts/ChartjsConfig";

// Import pages

import PMSReport from "./pages/PMSReport";
import CostSheet from "./pages/CostSheet";
import RmMovement from "./pages/RmMovement";
import ActualPrice from "./pages/ActualPrice";
import SignIn from "./pages/SignIn";
import ForgotPassword from "./pages/ForgotPassword";
import SignUp from "./pages/SignUp";

function App() {
  const location = useLocation();

  useEffect(() => {
    document.querySelector("html").style.scrollBehavior = "auto";
    window.scroll({ top: 0 });
    document.querySelector("html").style.scrollBehavior = "";
  }, [location.pathname]); // triggered on route change

  return (
    <>
      <Routes>
        <Route exact path="/" element={<PMSReport />} />
        <Route exact path="/pmsReport" element={<PMSReport />} />
        <Route exact path="/rmMovement" element={<RmMovement />} />
        <Route exact path="/costSheet" element={<CostSheet />} />
        <Route exact path="/actualPrice" element={<ActualPrice />} />
        <Route exact path="/login" element={<SignIn />} />
        <Route exact path="/forgotPassword" element={<ForgotPassword />} />
        <Route exact path="/registration" element={<SignUp />} />
      </Routes>
    </>
  );
}

export default App;
