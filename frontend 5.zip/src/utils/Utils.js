import resolveConfig from "tailwindcss/resolveConfig";
import tailwindConfigFile from "@tailwindConfig";
import ExcelJS from "exceljs";
import FileSaver from "file-saver";

export const tailwindConfig = () => {
  return resolveConfig(tailwindConfigFile);
};

export const hexToRGB = (h) => {
  let r = 0;
  let g = 0;
  let b = 0;
  if (h.length === 4) {
    r = `0x${h[1]}${h[1]}`;
    g = `0x${h[2]}${h[2]}`;
    b = `0x${h[3]}${h[3]}`;
  } else if (h.length === 7) {
    r = `0x${h[1]}${h[2]}`;
    g = `0x${h[3]}${h[4]}`;
    b = `0x${h[5]}${h[6]}`;
  }
  return `${+r},${+g},${+b}`;
};

export const formatValue = (value) =>
  Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumSignificantDigits: 3,
    notation: "compact",
  }).format(value);

export const formatThousands = (value) =>
  Intl.NumberFormat("en-US", {
    maximumSignificantDigits: 3,
    notation: "compact",
  }).format(value);

export const exportPmsReportToCSV = async (csvData, fileName) => {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Sheet1");

  const Heading1 = [
    ["Sr.", "Part No.", "Part Name", "Model Name", "Vendor Code"],
  ];
  const Heading2 = [
    [
      "SOP Actualization Q2",
      "RM Movement Q2",
      "NTF To Be PO Price Q2",
      "NTF Actual PO Price Q2",
      "Impact Q2",
      "RM Movement Q3",
      "NTF To Be PO Price Q3",
      "NTF Actual PO Price Q3",
      "Impact Q3",
      "RM Movement Q4",
      "PCD1 Q4",
      "To Be PO Price Q4",
      "NTF Actual PO Price Q4",
      "Impact Q4",
      "PCD2 Q1",
      "To Be PO Price Q1",
      "NTF Actual PO Price Q1",
      "Impact Q1",
    ],
  ];
  const Heading3 = [
    [
      "w.e.f.01.04.2023",
      "w.e.f.01.07.2023",
      "w.e.f.01.07.2023",
      "w.e.f.01.07.2023",
      "w.e.f.01.07.2023",
      "w.e.f.01.10.2023",
      "w.e.f.01.10.2023",
      "w.e.f.01.10.2023",
      "w.e.f.01.10.2023",
      "w.e.f.01.01.2024",
      "w.e.f.01.01.2024",
      "w.e.f.01.01.2024",
      "w.e.f.01.01.2024",
      "w.e.f.01.01.2024",
      "w.e.f.01.01.2025",
      "w.e.f.01.01.2025",
      "w.e.f.01.01.2025",
      "w.e.f.01.01.2025",
    ],
  ];
  const Heading4 = [
    [
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
      "Rs/Pc",
    ],
  ];

  sheet.addRow([...Heading1[0], ...Heading2[0]]);
  sheet.addRow(["", "", "", "", "", ...Heading3[0]]);
  sheet.addRow(["", "", "", "", "", ...Heading4[0]]);

  csvData.forEach((row, index) => {
    const rowIndex = index + 5; // Start from the 5th row
    const newRow = sheet.addRow(Object.values(row));

    // Apply conditional formatting based on the value
    newRow.eachCell((cell) => {
      if (typeof cell.value === "number") {
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: cell.value < 0 ? "FFFF0000" : "FF00FF00" }, // Red for negative, Green for positive
        };
      }
    });
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  FileSaver.saveAs(blob, fileName + ".xlsx");
};

export const exportActualPriceToCSV = (csvData, fileName) => {
  const fileType =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  const fileExtension = ".xlsx";

  const Heading1 = [
    [
      "Part No",
      "PO Type",
      "NTF Actual PO Price Q1 FY 2023",
      "NTF  Actual PO Price Q2 FY 2023",
      "NTF Actual PO Price Q3 FY 2023",
      "NTF Actual PO Price  Q3 FY 2023",
    ],
  ];
  const ws = XLSX.utils.json_to_sheet(csvData, {
    origin: "A3",
    skipHeader: true,
  });
  XLSX.utils.sheet_add_aoa(ws, Heading1, { origin: "A1" });
  const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
  const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const data = new Blob([excelBuffer], { type: fileType });
  FileSaver.saveAs(data, fileName + fileExtension);
};

export const exportRmMovementToCSV = (csvData, fileName) => {
  const fileType =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  const fileExtension = ".xlsx";

  const Heading1 = [
    [
      "RM Name",
      "RM Supplier Name",
      "Q1 FY 2023",
      "Q2 FY 2023",
      "Q3 FY 2023",
      "Q4 FY 2023",
    ],
  ];
  const ws = XLSX.utils.json_to_sheet(csvData, {
    origin: "A3",
    skipHeader: true,
  });
  XLSX.utils.sheet_add_aoa(ws, Heading1, { origin: "A1" });
  const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
  const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const data = new Blob([excelBuffer], { type: fileType });
  FileSaver.saveAs(data, fileName + fileExtension);
};

export const exportTCostSheetToCSV = (csvData, fileName) => {
  const fileType =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  const fileExtension = ".xlsx";

  const Heading1 = [
    [
      "Part No.",
      "Part Name",
      "PO Type",
      "Model",
      "RM Base",
      "SOP",
      "Vcode",
      "Cost Type",
      "RM Name",
      "Supplier name",
      "RM Weight Kg/Pc",
      "RM Rate R/Kg",
      "RM Rate Rs/Pc",
      "Indexing / MSIL Directed",
      "pcd_1",
      "pcd_1_date",
      "pcd_2",
      "pcd_2_date",
      "pcd_3",
      "pcd_3_date",
      "pcd_4",
      "pcd_4_date",
    ],
  ];
  const ws = XLSX.utils.json_to_sheet(csvData, {
    origin: "A3",
    skipHeader: true,
  });
  XLSX.utils.sheet_add_aoa(ws, Heading1, { origin: "A1" });
  const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
  const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const data = new Blob([excelBuffer], { type: fileType });
  FileSaver.saveAs(data, fileName + fileExtension);
};
