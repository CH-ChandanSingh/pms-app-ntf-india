import mysql from "mysql2/promise";

// connecting Database
export const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "dmsDelhi@123",
  database: "NTF",
});
