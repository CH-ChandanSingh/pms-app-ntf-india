import mysql from "mysql2";

// connecting Database
export const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "dmsDelhi@123",
  database: "NTF",
});
